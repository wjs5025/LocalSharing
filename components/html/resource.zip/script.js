$(window).on('load', function() {
    $('h1').text('hello World!!')
})